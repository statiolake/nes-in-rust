/*
 * mrustc Standalone MIRI
 * - by John Hodge (Mutabah)
 *
 * hir/type.hpp
 * - Forwarding header so mrustc's mir.hpp can be imported
 */
#include "../hir_sim.hpp"
