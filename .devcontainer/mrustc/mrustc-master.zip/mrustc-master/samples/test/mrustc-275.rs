fn fun1() -> () {
    return {
        return ();
    };
}

fn main() {}
