static mut GSLICE: &'static mut[u8] = &mut[];
fn main(){
  let _ = GSLICE;
}