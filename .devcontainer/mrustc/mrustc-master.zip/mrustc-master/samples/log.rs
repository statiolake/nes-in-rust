
#[macro_export]
macro_rules! error{
    ($( $v:tt )*) => {()};
}

